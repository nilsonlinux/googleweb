# google-forms
Basic google-form templates with link to demo/explanation

The following will explain at the most basic level how to set up a simple html form that will collect responses on a Google Doc. Here is the basic walkthrough you will need to reference: 

[Demo and explanation of google form usage](https://github.com/dwyl/html-form-send-email-via-google-script-without-server)

*You will only need to complete steps 1-6 of this walkthrough! The rest are taken care of for you and will be explained here*

# After completing Steps 1-6 of the walkthrough

You should now have your google doc set up (don't need columns set up just yet, just the empty form), and you should have a *link* from the end of Step 6 ("Current web app URL"). Please follow the following steps if so:

1. Select one of the basic forms provided for you in the repository (materialize-form, materialize-form2, materialize-form3). Make any style adjustments you would like (color, copy, etc). Here are the 3 forms for reference:

-[materialize-form](https://github.com/represently/google-forms/tree/master/images/1.png)

-[materialize-form2](https://github.com/represently/google-forms/tree/master/images/2.png)

-[materialize-form3](https://github.com/represently/google-forms/tree/master/images/3.png)

*To check out these forms and play around with them, simply download the html files directly from here and open the files on your computer. This should bring up your browser and show you the form*

2. Copy the link from above from the end of Step 6 ("Current web app URL") and paste it in the "action" field in the following location:

```
<form class="col s10 offset-s1 m8 offset-m2" id="gform" method="POST" action="PASTE URL HERE">
```

*Make sure that the url has quotes around it*

3. Based on what form you chose, label your columns in your google doc as such:
* materialize-form --> first_name, last_name, email 
* materialize-form2 --> first_name, last_name, email, message
* materialize-form3 --> first_name, last_name, email, organization, message

4. Technically, you should be done at this point. I will provide a couple common problems or mistakes at this point in case you run into them:

* If you are getting "undefined" in your google doc when you trying submitting information, please make sure you followed step 3 exactly as it is outlined. Your columns need to match the exact format from above (case sensitive) 
* If nothing is posting in your google doc, please make sure your link is correctly copied into the action field (run through step 2) 


*If you would like to make other customizations on the forms, please seek help from devs (addition fields in form, large styling changes, making certain fields required and others not, etc)*


